package miniproject.catchmind;

public class IdNameScoreDTO {
	private String Id;
	private String Name;
	private int Score;
	
	public String getId() {
		return Id;
	}
	public void setId(String id) {
		Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getScore() {
		return Score;
	}
	public void setScore(int score) {
		Score = score;
	}
	public String toString() {
		return Id;
	}
	
}
